-- Entregue la fecha en que se casaron los padres de ‘Tito Fernández’
-- SIN JOIN (opcion 1)
SELECT m.fecha FROM 
   matrimonio m, 
   (SELECT rut_padre, rut_madre FROM desendiente WHERE rut_desc = 
                               ( SELECT rut from Hombre where nombre = 'Tito Fernandez' )) p
   WHERE m.rut_mujer=p.rut_madre
	AND m.rut_hombre=p.rut_padre;


-- CON JOIN (opcion 2)
SELECT m.fecha FROM matrimonio m,
	JOIN  desendiente d
      on m.rut_mujer=d.rut_madre AND m.rut_hombre=d.rut_padre
	JOIN  (SELECT rut from Hombre where nombre = 'Tito Fernandez') tito
	  on d.rut_desc = tito.rut 


-- Entregue la edad promedio por comuna en que se casaron las mujeres junto con la edad promedio por comuna en que se casaron los hombres (suponga que la edad que figura en las relaciones corresponde a la edad que tenían al momento de casarse).
SELECT m.comuna, avg(m.edad) as avg_edad_mujer , avg(h.edad) FROM mujer m, hombre h WHERE m.comuna = h.comuna GROUP BY m.comuna;

SELECT m_data.comuna, m_data.avg_edad_mujer, h_data.avg_edad_hombre  
  FROM (SELECT m.comuna, avg(m.edad) as avg_edad_mujer FROM mujer m GROUP BY m.comuna) m_data 
    FULL JOIN (SELECT h.comuna, avg(h.edad) as avg_edad_hombre FROM hombre h GROUP BY h.comuna) h_data 
      on m_data.comuna = h_data.comuna;

-- Liste el nombre de los abuelos (hombres) de ‘Darla Latamagna’.

SELECT  abuelo1.nombre, abuelo2.nombre FROM (select rut from mujer where nombre = 'Juana de Arco') hija
	JOIN (SELECT rut_madre, rut_padre, rut_desc FROM desendiente) padres
		on padres.rut_desc = hija.rut
	JOIN (SELECT rut_padre as rut_abuelo_paterno, rut_desc from desendiente) abuelo_paterno
		on abuelo_paterno.rut_desc=padres.rut_padre
	JOIN (SELECT rut_padre as rut_abuelo_materno, rut_desc from desendiente) abuelo_materno
		on abuelo_materno.rut_desc=padres.rut_madre
	JOIN hombre abuelo1
		on abuelo1.rut = rut_abuelo_paterno
	JOIN hombre abuelo2
		on abuelo2.rut = rut_abuelo_materno


-- Entregue todas las posibles parejas de hombres y mujeres (en forma de nombres), tales que el hombre no tenga hijos, y la mujer sea menor de 30 años.
SELECT hombre.nombre, mujer.nombre FROM (
 SELECT * FROM (
  SELECT m.rut_hombre, m.rut_mujer, count(d.rut_padre) FROM desendiente d 
     RIGHT JOIN  (SELECT rut_hombre, rut_mujer FROM matrimonio) m 
    	ON d.rut_padre = m.rut_hombre 
     GROUP BY (m.rut_mujer, m.rut_hombre)
 ) r1
 WHERE r1.count=0
) r2
JOIN hombre ON r2.rut_hombre = hombre.rut
JOIN mujer ON r2.rut_mujer = mujer.rut;


-- Entregue los nombres de hombres y mujeres de matrimonios separados/divorciados (aquellos que no viven en la misma dirección).
SELECT hombre.nombre, mujer.nombre FROM matrimonio m
	JOIN hombre 
		ON hombre.rut = m.rut_hombre
	JOIN mujer
		ON mujer.rut = m.rut_mujer
	WHERE hombre.direccion != mujer.direccion

		
